const unsigned long serialBaudrate = 115200;  // Baudrate of Serial connection.

bool lastState = true;
bool state;
unsigned int stateChangeCount = 0;
